import 'package:flutter/material.dart';
import 'SignIn.dart';

void main() {
  runApp(const NextChapterApp());
}

class NextChapterApp extends StatelessWidget {
  const NextChapterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'NextChapter',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        useMaterial3: true,
      ),
      debugShowCheckedModeBanner: false,
      home: const SignInScreen(),
    );
  }
}
