import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';

class AudioBookDetailPage extends StatefulWidget {
  @override
  _AudioBookDetailPageState createState() => _AudioBookDetailPageState();
}

class _AudioBookDetailPageState extends State<AudioBookDetailPage> {
  late AudioPlayer _audioPlayer;

  @override
  void initState() {
    super.initState();
    _audioPlayer = AudioPlayer();
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    super.dispose();
  }

  Future<void> playAudio() async {
    try {
      await _audioPlayer.setAsset('assets/sounds/sound1.mp3');
      _audioPlayer.play();
    } catch (e) {
      print('Error playing audio: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Detail"),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        elevation: 0,
        backgroundColor: const Color(0xFFF7F6F1),
        foregroundColor: Colors.black,
      ),
      body: Container(
        color: const Color(0xFFF7F6F1),
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // Book Cover Image
            ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: Image.asset(
                'assets/images/book1.jpg', // Replace with your book cover image
                height: 300,
                fit: BoxFit.cover,
              ),
            ),
            const SizedBox(height: 16),
            // Book Title
            const Text(
              'Frankenstein\nThe Modern Prometheus (1818)',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            // Author Name
            const Text(
              'Mary Wollstonecraft Shelley',
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey,
              ),
            ),
            const SizedBox(height: 16),
            // Icons and Genre
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(
                  icon: const Icon(Icons.share),
                  onPressed: () {
                    // Share functionality
                  },
                ),
                const SizedBox(width: 16),
                IconButton(
                  icon: const Icon(Icons.bookmark_border),
                  onPressed: () {
                    // Bookmark functionality
                  },
                ),
                const SizedBox(width: 16),
                const Text(
                  'Fantasy · Novel',
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.grey,
                  ),
                ),
              ],
            ),
            const Spacer(),
            // Listen to the Book Button
            ElevatedButton.icon(
              onPressed: playAudio,
              icon: const Icon(Icons.volume_up),
              label: const Text('Listen to the book'),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFDFD5B7),
                foregroundColor: Colors.black,
                padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}

void main() {
  runApp(MaterialApp(
    home: AudioBookDetailPage(),
  ));
}
